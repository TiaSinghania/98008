/// Make me compile!
/// Hint: Run `cargo test` and see what the compiler tells you! Are you missing any keywords?

#[test]
fn dont_change_me() {
    let mut x = 3;
    println!("Number {}", x);
    x = 5; // don't change this line
    println!("Number {}", x);
}
