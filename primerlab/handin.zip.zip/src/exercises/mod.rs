//! All examples taken from [rustlings
//! exercises](https://github.com/rust-lang/rustlings/tree/main/exercises)
//!
//! Uncomment each of these and ensure that it compiles with `cargo test -- fixme`.
//! We recommend uncommenting them one at a time.
//! Make sure you read ALL of the error messages! They contain VERY useful information.

pub mod fixme1;
pub mod fixme2;
pub mod fixme3;
pub mod fixme4;
pub mod fixme5;
pub mod fixme6;
pub mod fixme7;
pub mod fixme8;

// Rustlings exercise reference:
// Exercise 1: variables exercise number 1
// Exercise 2: variables exercise number 4
// Exercise 3: functions exercise number 2
// Exercise 4: functions exercise number 4
// Exercise 5: functions exercise number 5
// Exercise 6: primitive_types exercise number 5
// Exercise 7: primitive_types exercise number 6
// Exercise 8: primitive_types exercise number 3
